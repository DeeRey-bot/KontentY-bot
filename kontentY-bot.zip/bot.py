
import telebot

TOKEN = "8308401763:AAG9sffExUu1EYUBKAoCb_6NJS2qSw5iBGo"
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Добро пожаловать в Контент-Бот! Всё работает на тебя.")

@bot.message_handler(commands=['help'])
def send_help(message):
    bot.reply_to(message, "/start - запуск бота\n/help - помощь\n/status - статус системы")

@bot.message_handler(commands=['status'])
def send_status(message):
    bot.reply_to(message, "Система работает стабильно. Продолжай делиться контентом!")

bot.polling()
